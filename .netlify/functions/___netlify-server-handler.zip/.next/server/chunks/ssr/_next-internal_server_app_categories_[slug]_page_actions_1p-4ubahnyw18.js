module.exports=[71651,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_categories_%5Bslug%5D_page_actions_1p-4ubahnyw18.js.map