globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/FDtwBq4UxqA9fLLCezObb/_buildManifest.js",
    "static/FDtwBq4UxqA9fLLCezObb/_ssgManifest.js",
    "static/FDtwBq4UxqA9fLLCezObb/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1x6obpmlu1_c2.js",
    "static/chunks/11t-zvhau74r5.js",
    "static/chunks/2ki52vdnbo2ft.js",
    "static/chunks/0ds-6qu3100c2.js",
    "static/chunks/turbopack-3-ry682tkyiqk.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/11t-zvhau74r5.js",
        "static/chunks/2ki52vdnbo2ft.js",
        "static/chunks/0ds-6qu3100c2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/11t-zvhau74r5.js",
        "static/chunks/2ki52vdnbo2ft.js",
        "static/chunks/0ds-6qu3100c2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/11t-zvhau74r5.js",
        "static/chunks/2ki52vdnbo2ft.js",
        "static/chunks/0ds-6qu3100c2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/account/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/11t-zvhau74r5.js",
        "static/chunks/2ki52vdnbo2ft.js",
        "static/chunks/0ds-6qu3100c2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/account/rewards/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/11t-zvhau74r5.js",
        "static/chunks/2ki52vdnbo2ft.js",
        "static/chunks/0ds-6qu3100c2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/11t-zvhau74r5.js",
        "static/chunks/2ki52vdnbo2ft.js",
        "static/chunks/0ds-6qu3100c2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/analytics/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/11t-zvhau74r5.js",
        "static/chunks/2ki52vdnbo2ft.js",
        "static/chunks/0ds-6qu3100c2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/analytics/content/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/11t-zvhau74r5.js",
        "static/chunks/2ki52vdnbo2ft.js",
        "static/chunks/0ds-6qu3100c2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/analytics/revenue/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/11t-zvhau74r5.js",
        "static/chunks/2ki52vdnbo2ft.js",
        "static/chunks/0ds-6qu3100c2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/campaigns/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/11t-zvhau74r5.js",
        "static/chunks/2ki52vdnbo2ft.js",
        "static/chunks/0ds-6qu3100c2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/categories/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/11t-zvhau74r5.js",
        "static/chunks/2ki52vdnbo2ft.js",
        "static/chunks/0ds-6qu3100c2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/referrals/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/11t-zvhau74r5.js",
        "static/chunks/2ki52vdnbo2ft.js",
        "static/chunks/0ds-6qu3100c2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/reports/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/11t-zvhau74r5.js",
        "static/chunks/2ki52vdnbo2ft.js",
        "static/chunks/0ds-6qu3100c2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/settings/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/11t-zvhau74r5.js",
        "static/chunks/2ki52vdnbo2ft.js",
        "static/chunks/0ds-6qu3100c2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/users/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/11t-zvhau74r5.js",
        "static/chunks/2ki52vdnbo2ft.js",
        "static/chunks/0ds-6qu3100c2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/videos/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/11t-zvhau74r5.js",
        "static/chunks/2ki52vdnbo2ft.js",
        "static/chunks/0ds-6qu3100c2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/auth/reset/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/11t-zvhau74r5.js",
        "static/chunks/2ki52vdnbo2ft.js",
        "static/chunks/0ds-6qu3100c2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/auth/sign-in/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/11t-zvhau74r5.js",
        "static/chunks/2ki52vdnbo2ft.js",
        "static/chunks/0ds-6qu3100c2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/auth/sign-up/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/11t-zvhau74r5.js",
        "static/chunks/2ki52vdnbo2ft.js",
        "static/chunks/0ds-6qu3100c2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/categories/[slug]/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/11t-zvhau74r5.js",
        "static/chunks/2ki52vdnbo2ft.js",
        "static/chunks/0ds-6qu3100c2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/community/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/11t-zvhau74r5.js",
        "static/chunks/2ki52vdnbo2ft.js",
        "static/chunks/0ds-6qu3100c2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/drama/[slug]/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/11t-zvhau74r5.js",
        "static/chunks/2ki52vdnbo2ft.js",
        "static/chunks/0ds-6qu3100c2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/explore/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/11t-zvhau74r5.js",
        "static/chunks/2ki52vdnbo2ft.js",
        "static/chunks/0ds-6qu3100c2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/premium/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/11t-zvhau74r5.js",
        "static/chunks/2ki52vdnbo2ft.js",
        "static/chunks/0ds-6qu3100c2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/privacy/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/11t-zvhau74r5.js",
        "static/chunks/2ki52vdnbo2ft.js",
        "static/chunks/0ds-6qu3100c2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/saved/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/11t-zvhau74r5.js",
        "static/chunks/2ki52vdnbo2ft.js",
        "static/chunks/0ds-6qu3100c2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/search/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/11t-zvhau74r5.js",
        "static/chunks/2ki52vdnbo2ft.js",
        "static/chunks/0ds-6qu3100c2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/terms/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/11t-zvhau74r5.js",
        "static/chunks/2ki52vdnbo2ft.js",
        "static/chunks/0ds-6qu3100c2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/v/[slug]/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/11t-zvhau74r5.js",
        "static/chunks/2ki52vdnbo2ft.js",
        "static/chunks/0ds-6qu3100c2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/watch/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/11t-zvhau74r5.js",
        "static/chunks/2ki52vdnbo2ft.js",
        "static/chunks/0ds-6qu3100c2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
